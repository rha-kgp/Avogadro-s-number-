import java.util.ArrayList;
import java.util.Scanner;

public class Avo {

    public static double [] Avo(ArrayList<Double> numbers) {

        double n = 9.135 * 10E-8;
        double p = 0.5 * 10E-6;
        double T = 297;
        double R = 8.31446;
        double variance;
        double D;
        double k;
        double NA;
        double sum = 0;
        double[] Avo = new double[2];



        for (int i = 0; i < numbers.size(); i++) {

            double num = numbers.get(i) * (0.175 * 10E-6) ;
            sum += Math.pow(num , 2) ;
        }

        variance = sum / (2 * numbers.size());

        D = variance;

        k = (6 * Math.PI * n * p * D) / T;

        NA = R / k;


        Avo[0] = k;
        Avo[1] = NA;


        return Avo;
    }


    public static void main(String [] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Double> num = new ArrayList<>();
        double[] result;

        while(sc.hasNextDouble()){

            num.add(sc.nextDouble());
        }

        result = Avo(num);

        System.out.println("k = " + result[0]);
        System.out.println("avogadro number = " + result[1]);

    }

}

// raha


