import java.io.File;
import java.util.LinkedList;

public class BeadTracker {

        public Picture picture1;
        public Picture picture2;
        public double tau;
        public int min;

        // creating a constructor
        public BeadTracker(int min_ , double tau_ , Picture picture1_ , Picture picture2_) {

                this.min = min_;
                this.tau = tau_;
                this.picture1 = picture1_;
                this.picture2 = picture2_;
        }

        LinkedList <Double> x = new LinkedList<>() ;
        LinkedList <Double> y = new LinkedList<>() ;

        // search the qualified area (a circle)
        public Boolean circle(double x, double y, double xc, double yc, int d){

                if(Math.pow(x - xc , 2) + Math.pow(y - yc , 2) < Math.pow(d , 2)) return true;

                return false;

        }


        public void BeadTracker(Picture picture1,Picture picture2, int d) {

                //*********** getting the beads of first frame ************

                BeadFinder bead1 = new BeadFinder(picture1, tau);
                Blob[] beadsArray1 = new Blob[100];

                for (int i = 0; i < 100; i++) {
                        beadsArray1[i] = new Blob();

                }

                beadsArray1 = bead1.getBeads(min);


                //*********** getting the beads of second frame ***********

                BeadFinder bead2 = new BeadFinder(picture2, tau);
                Blob[] beadsArray2 = new Blob[100];

                for (int i = 0; i < 100; i++) {
                        beadsArray2[i] = new Blob();
                }

                beadsArray2 = bead2.getBeads(min);


                //*********** center of each bead in 1st frame ************

                for (int i = 0; i < beadsArray1.length; i++) {

                        double[] center = beadsArray1[i].BlobCenter();
                        double xc = center[0];
                        double yc = center[1];


                        //************ center of all beads in 2nd frame ***********

                        for (int j = 0; j < beadsArray2.length; j++) {
                                x.add(beadsArray2[j].BlobCenterX());
                                y.add(beadsArray2[j].BlobCenterY());
                        }


                        //************ creating an array of blobs **************

                        Blob[] qualified = new Blob[x.size()];

                        for (int k = 0; k < x.size(); k++) {
                                qualified[k] = new Blob();
                        }

                        //************* beads in 25 **************

                        for (int h = 0; h < qualified.length; h++) {

                                double xT = x.get(h);
                                double yT = y.get(h);

                                if (circle(xT, yT, xc, yc, d)) {
                                        qualified[h].add(xT, yT);
                                }
                        }

                        double mind = d;

                        for (int h = 0; h < qualified.length; h++) {
                                mind = Math.min(qualified[h].distanceTo(beadsArray1[i]), mind);
                        }

                        if(mind < d) {
                                System.out.println(mind);
                        }
                }

        }

        public static void main(String[] args) {

                int min_ = Integer.parseInt(args[0]); //25
                double tau_ = Double.parseDouble(args[1]); //180
                int d = Integer.parseInt(args[2]); //25
                String path = args[3];

                String folderPath = path.substring(0, Math.min(path.length(), 5));
                File p = new File(folderPath);


                //****** an array of strings ****************

                String [] pathList = p.list();

                for (int i = 0; i < pathList.length - 1; i++) {
                        String pic1Name = folderPath + "/" + pathList[i];
                        String pic2Name = folderPath + "/" + pathList[i + 1];

                        Picture picture1_ = new Picture(pic1Name);
                        Picture picture2_ = new Picture(pic2Name);

                        BeadTracker beadTracker = new BeadTracker(min_, tau_, picture1_, picture2_);
                        beadTracker.BeadTracker(picture1_, picture2_, d);

                }

        }

}

