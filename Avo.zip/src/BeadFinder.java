import java.awt.*;
import java.util.LinkedList;

public class BeadFinder {

    Picture picture;
    double tau;

    LinkedList<Blob> Beads = new LinkedList<>();

    int [][] pixel = new int[640][480];

    public BeadFinder (Picture picture , double tau) {

        for (int i = 0; i < 640; i++) {
            for (int j = 0; j < 480; j++) {

                //returns the color of each pixel
                Color color = picture.get(i, j);

                double R = color.getRed();
                double G = color.getGreen();
                double B = color.getBlue();

                // 0 => background
                if (R < tau && G < tau && B < tau) {
                    pixel[i][j] = 0;
                }

                // 1 => blob
                else {
                    pixel[i][j] = 1;
                }
            }
        }
    }


    public BeadFinder () {}


    public void BF (int [][] pixel , Blob blob, int counter , int i , int j) {

        // Stop Conditions

        if( i == -1 || i >= 640 || j == -1 || j >= 480)  return;

        if (pixel [i][j] == 0) return;

        if( pixel [i][j] == 1) {

            blob.add(i , j);

            // Flagging added blobs
            pixel [i][j] = 2;

            BF(pixel , blob , counter , i-1 , j);
            BF(pixel , blob , counter , i+1 , j);
            BF(pixel , blob , counter , i , j-1);
            BF(pixel , blob , counter , i , j+1);

        }


    }

    public Blob[] getBeads(int min) {

        for(int i = 0 ; i < 640 ; i++) {
            for(int j = 0 ; j < 480 ; j++) {

                if(pixel[i][j] == 1) {
                    Blob blob = new Blob();
                    BF(pixel , blob , 0 , i , j);

                    if(blob.mass() > min) {
                        Beads.add(blob);
                }
            }
        }

    }

        // creates an array of blobs
        // then adds beads to this array

        Blob [] beads = new Blob[Beads.size()];

        for(int k = 0 ; k < Beads.size() ; k++){
            beads[k] = Beads.get(k);
        }

        return beads;

    }
    public static void main(String[] args) {

        // using the terminal

        double tau = Double.parseDouble(args[1]);
        int min = Integer.parseInt(args[0]);
        Picture picture1 = new Picture(args[2]);
        BeadFinder bead = new BeadFinder(picture1, tau);

        // 100 is just an arbitrary number

        Blob [] beads = new Blob[100];
        for (int i = 0; i < 100; i++) {
            beads[i] = new Blob();
        }
        beads = bead.getBeads(min);

        for(int i=0 ; i < beads.length; i++){
            System.out.println(beads[i].toString());
        }
    }

}

