import java.util.LinkedList;

public class Blob {

    LinkedList<Double> xs = new LinkedList<>();
    LinkedList<Double> ys = new LinkedList<>();

    public Blob(){}

    public void add(double x , double y) {
        xs.add(x);
        ys.add(y);
    }

    public int mass() {
        return xs.size();
    }

    public double BlobCenterX() {

        double sumX = 0;

        for( int i = 0; i < xs.size(); i++) {
            sumX += xs.get(i);
        }

        double xc = four(sumX / xs.size());

        return xc;
    }

    public double BlobCenterY() {

        double sumY = 0;

        for( int i = 0; i < ys.size(); i++) {
            sumY += ys.get(i);
        }

        double yc = four(sumY / ys.size());

        return yc;
    }

    public double [] BlobCenter() {

        double sumX = 0;
        double sumY = 0;

        for( int i = 0; i < xs.size(); i++) {
            sumX += xs.get(i);
            sumY += ys.get(i);

        }

        double xc = four(sumX / xs.size());
        double yc = four(sumY / ys.size());

        double [] centers = new double[2];

        centers [0] = xc;
        centers [1] = yc;

        return centers;
    }



    public double distanceTo(Blob that) {

        double That [] = that.BlobCenter();
        double This [] = this.BlobCenter();

        double x = four(Math.pow(This [0] - That [0] , 2));
        double y = four(Math.pow(This [1] - That [1] , 2));

        double distance = four(Math.sqrt(x + y));
        return distance;
    }

    public double four(double number){
        number = number * 10000;
        int num = (int) number;
        double numb = (double) num/10000;
        return numb;
    }

    public String toString() {

        double Center [] = BlobCenter();
        int BlobMass = xs.size();

        String centerX = String.format("%.4f" , Center[0]);
        String centerY = String.format("%.4f" , Center[1]);

        return BlobMass + " (" + centerX + "," + centerY + ")";
    }

    public static void main(String[] args) {
        Blob b = new Blob();
        b.add(0, 0);

        Blob b2 = new Blob();
        b2.add(3, 4);

        System.out.println(b.toString());
        System.out.println(b.distanceTo(b2));
    }

}
